-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2025 at 01:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pafonlinetest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'shahbaz', '$2y$10$ssvKE0v0SnF6H7RgtlzEr.ZCnB7n.7r4Bsr.mrDS6Sta9FkHzbKEi', '2024-08-22 10:54:35'),
(2, 'zainab', '$2y$10$kLDdIOdterjXdsGjzDlcLO/LZ0nacS3vkxPT5Y0Qq36UrG.vjt3zS', '2024-10-05 05:07:23');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `mark_for_review` tinyint(1) DEFAULT 0,
  `is_correct` tinyint(1) DEFAULT NULL,
  `is_skipped` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `user_id`, `question_id`, `answer`, `mark_for_review`, `is_correct`, `is_skipped`) VALUES
(9302, '1111', 656, 'B', 0, NULL, 0),
(9303, '1111', 657, 'B', 0, NULL, 0),
(9304, '1111', 658, 'B', 0, NULL, 0),
(9305, '1111', 659, 'C', 0, NULL, 0),
(9306, '1111', 660, 'D', 0, NULL, 0),
(9307, '1111', 661, 'B', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `question_text` text DEFAULT NULL,
  `question_image` varchar(255) DEFAULT NULL,
  `option_a` text DEFAULT NULL,
  `option_a_image` varchar(255) DEFAULT NULL,
  `option_b` text DEFAULT NULL,
  `option_b_image` varchar(255) DEFAULT NULL,
  `option_c` text DEFAULT NULL,
  `option_c_image` varchar(255) DEFAULT NULL,
  `option_d` text DEFAULT NULL,
  `option_d_image` varchar(255) DEFAULT NULL,
  `correct_answer` varchar(1) DEFAULT NULL,
  `option_e` varchar(255) DEFAULT NULL,
  `option_e_image` varchar(255) DEFAULT NULL,
  `sequence_number` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `subject_id`, `question_text`, `question_image`, `option_a`, `option_a_image`, `option_b`, `option_b_image`, `option_c`, `option_c_image`, `option_d`, `option_d_image`, `correct_answer`, `option_e`, `option_e_image`, `sequence_number`) VALUES
(656, 50, 'Find the next number in the series: 2, 6, 12, 20, 30, ?', NULL, '36', NULL, '44', NULL, '40', NULL, '', NULL, 'E', '42', NULL, 1),
(657, 50, 'Which word does NOT belong in the group?', NULL, 'Inch', NULL, 'Kilogram', NULL, 'Yard', NULL, 'Mile', NULL, 'B', '', NULL, 2),
(658, 51, 'A shirt costs $240. It is sold at a 25% discount. What is the selling price?', NULL, ' $160', NULL, '$170', NULL, '$180', NULL, '$200', NULL, 'C', '', NULL, 1),
(659, 51, 'A car travels 180 km in 3 hours. What is its average speed?', NULL, '50 km/h', NULL, '55 km/h', NULL, '60 km/h', NULL, '65 km/h', NULL, 'C', '', NULL, 2),
(660, 52, 'Choose the word that means the same as \"Rapid\":', NULL, 'Slow', NULL, 'Quick', NULL, 'Small', NULL, 'Heavy', NULL, 'B', '', NULL, 1),
(661, 52, 'Choose the correct sentence:', NULL, 'She don’t like coffee.', NULL, 'She doesn’t likes coffee.', NULL, 'She doesn’t like coffee.', NULL, 'She don’t likes coffee.', NULL, 'C', '', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `correct_answers` int(11) NOT NULL DEFAULT 0,
  `total_questions` int(11) NOT NULL DEFAULT 0,
  `percentage` float NOT NULL DEFAULT 0,
  `subject_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `user_id`, `correct_answers`, `total_questions`, `percentage`, `subject_id`) VALUES
(389, '1111', 1, 2, 50, 50),
(390, '1111', 1, 2, 50, 51),
(391, '1111', 0, 2, 0, 52);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `test_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `time_in_minutes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `test_id`, `name`, `time_in_minutes`) VALUES
(50, 15, 'Intelligence', 5),
(51, 15, 'Math', 5),
(52, 15, 'English', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `test_id` varchar(50) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `date_added` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `test_id`, `test_name`, `date_added`) VALUES
(15, 'TestID', 'Paf Sargodha', '2025-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `useres`
--

CREATE TABLE `useres` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `group_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useres`
--

INSERT INTO `useres` (`id`, `name`, `father_name`, `picture`, `group_name`) VALUES
('1111', '11', '11', 'uploads/Screenshot 2025-07-22 215551.png', 'Group1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_ibfk_1` (`subject_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_id` (`test_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `useres`
--
ALTER TABLE `useres`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9308;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=662;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=392;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `useres` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
