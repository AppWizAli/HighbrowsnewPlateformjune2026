<?php
// Centralized database configuration
// Change these settings based on your environment

// Local development settings
$DB_CONFIG = [
    'host' => 'localhost',
    'dbname' => 'pafonlinetest',
    'user' => 'root',
    'pass' => ''
];

// Production settings (uncomment when deploying)
/*
$DB_CONFIG = [
    'host' => 'localhost',
    'dbname' => 'u379508397_pafOnlineFinal',
    'user' => 'u379508397_imranwaheed',
    'pass' => 'Imranwaheed3765@.'
];
*/

// Function to get PDO connection
function getPDOConnection() {
    global $DB_CONFIG;
    try {
        $pdo = new PDO(
            "mysql:host={$DB_CONFIG['host']};dbname={$DB_CONFIG['dbname']}", 
            $DB_CONFIG['user'], 
            $DB_CONFIG['pass']
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die('Connection failed: ' . $e->getMessage());
    }
}

// Function to get mysqli connection
function getMysqliConnection() {
    global $DB_CONFIG;
    $conn = new mysqli(
        $DB_CONFIG['host'], 
        $DB_CONFIG['user'], 
        $DB_CONFIG['pass'], 
        $DB_CONFIG['dbname']
    );
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}
?>
